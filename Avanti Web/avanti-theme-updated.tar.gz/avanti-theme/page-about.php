<?php
/**
 * Template Name: About Page
 *
 * @package Avanti_Classic
 */

get_header();
$theme_uri = get_template_directory_uri();
?>

    <!-- About Section -->
    <section id="about" class="about-section" style="padding-top: 12rem;">
        <div class="container about-container">
            <div class="about-image-column scroll-reveal">
                <div class="about-image-card">
                    <img src="<?php echo esc_url( $theme_uri ); ?>/assets/special_meal.png" alt="Avanti Gourmet Platter Plating" class="about-img">
                    <div class="card-glow"></div>
                </div>
            </div>
            
            <div class="about-content-column scroll-reveal">
                <h5 class="section-subtitle"><?php echo esc_html( get_theme_mod( 'avanti_about_subtitle', 'Our Journey' ) ); ?></h5>
                <h2 class="section-title"><?php echo esc_html( get_theme_mod( 'avanti_about_title', 'Moving Forward with Flavor Since 2012' ) ); ?></h2>
                <div class="section-divider"></div>
                <p class="about-text">
                    <?php echo esc_html( get_theme_mod( 'avanti_about_text1', "Founded in 2012 by partners with a shared vision of culinary excellence, Avanti Restaurant has become a benchmark for high-quality dining in Mymensingh Sadar. The name Avanti, meaning 'let's move forward' in Italian, guides our commitment to fresh ingredients and progressive recipes." ) ); ?>
                </p>
                <p class="about-text">
                    <?php echo esc_html( get_theme_mod( 'avanti_about_text2', 'We serve a wide variety of cuisines ranging from artisanal pizzas and creamy pasta to set platters and refreshing custom beverages. Every dish is cooked to order by our dedicated kitchen crew, ensuring a memorable dining experience for you and your family.' ) ); ?>
                </p>
                <div class="about-highlights">
                    <div class="highlight-item">
                        <i class="fa-solid fa-pizza-slice highlight-icon"></i>
                        <span>Artisanal Pizza</span>
                    </div>
                    <div class="highlight-item">
                        <i class="fa-solid fa-heart highlight-icon"></i>
                        <span>Fresh Ingredients</span>
                    </div>
                    <div class="highlight-item">
                        <i class="fa-solid fa-award highlight-icon"></i>
                        <span>14+ Years Legacy</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php get_footer(); ?>
