<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

    <!-- Header Navigation -->
    <header id="main-header">
        <div class="container header-container">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo">
                <?php 
                $logo_img = get_template_directory_uri() . '/assets/logo.png';
                if ( file_exists( get_template_directory() . '/assets/logo.png' ) ) : ?>
                    <img src="<?php echo esc_url( $logo_img ); ?>" alt="Avanti Logo" style="height: 48px; width: auto; margin-right: 10px;">
                <?php else : 
                    $logo_text = get_theme_mod( 'avanti_logo_text', 'Avanti' );
                    $first_char = substr($logo_text, 0, 1);
                    $rest_chars = substr($logo_text, 1);
                    ?>
                    <span class="logo-accent"><?php echo esc_html($first_char); ?></span><?php echo esc_html($rest_chars); ?>
                <?php endif; ?>
            </a>
            
            <?php
            $current_slug = '';
            if ( is_front_page() || is_home() ) {
                $current_slug = 'home';
            } else if ( is_page() ) {
                global $post;
                $current_slug = isset( $post->post_name ) ? $post->post_name : '';
            }
            ?>
            <?php
            $is_home = is_front_page() || is_home();
            ?>
            <nav id="navbar">
                <ul class="nav-links">
                    <li><a href="<?php echo $is_home ? '#home' : esc_url( home_url( '/' ) ); ?>" class="nav-link <?php echo ($current_slug === 'home') ? 'active' : ''; ?>">Home</a></li>
                    <li><a href="<?php echo $is_home ? '#about' : esc_url( home_url( '/about/' ) ); ?>" class="nav-link <?php echo ($current_slug === 'about') ? 'active' : ''; ?>">About</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/menu/' ) ); ?>" class="nav-link <?php echo ($current_slug === 'menu') ? 'active' : ''; ?>">Menu</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/chef-specials/' ) ); ?>" class="nav-link <?php echo ($current_slug === 'chef-specials') ? 'active' : ''; ?>">Chef Specials</a></li>
                    <li><a href="<?php echo $is_home ? '#gallery' : esc_url( home_url( '/gallery/' ) ); ?>" class="nav-link <?php echo ($current_slug === 'gallery') ? 'active' : ''; ?>">Gallery</a></li>
                    <li><a href="<?php echo $is_home ? '#reserve' : esc_url( home_url( '/contact/' ) ); ?>" class="nav-link <?php echo ($current_slug === 'contact') ? 'active' : ''; ?>">Contact</a></li>
                </ul>
            </nav>
            
            <div class="nav-actions">
                <button id="lang-toggle" class="lang-toggle-btn" aria-label="Toggle language">
                    <span class="lang-text-en active">EN</span>
                    <span class="lang-divider">/</span>
                    <span class="lang-text-bn">বাং</span>
                </button>
                <a href="<?php echo $is_home ? '#reserve' : esc_url( home_url( '/contact/' ) ); ?>" class="btn btn-primary nav-cta">Book Table</a>
            </div>
            
            <button class="mobile-nav-toggle" aria-label="Toggle navigation menu">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </button>
        </div>
    </header>
