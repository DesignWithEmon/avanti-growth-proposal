<?php
/**
 * Template Name: Menu Page
 *
 * @package Avanti_Classic
 */

get_header();
?>

    <!-- Menu Section -->
    <section id="menu" class="menu-section" style="padding-top: 12rem;">
        <div class="container menu-container">
            <div class="text-center scroll-reveal">
                <h5 class="section-subtitle">The Culinary List</h5>
                <h2 class="section-title">Savor Our Authentic Masterpieces</h2>
                <div class="section-divider center"></div>
                <p class="section-desc max-w-600">Explore Avanti's extensive menu in Mymensingh, featuring authentic Italian pizza, creamy pasta, gourmet set meals, and fresh custom drinks.</p>
            </div>
            
            <!-- Live Search Bar -->
            <div class="search-wrapper scroll-reveal" style="max-w-600; margin: -2rem auto 3rem auto; display: flex; gap: 10px; background: rgba(255,255,255,0.02); border: 1px solid var(--color-border); padding: 6px 12px; border-radius: var(--border-radius-sm); align-items: center;">
                <i class="fa-solid fa-magnifying-glass" style="color: var(--color-primary); font-size: 1.1rem;"></i>
                <input type="text" id="menu-search-input" placeholder="Search dishes by name or description..." style="width: 100%; border: none; outline: none; background: transparent; padding: 8px 4px; color: var(--color-text-main);">
                <button type="button" id="clear-search-btn" style="display: none; color: var(--color-text-muted); cursor: pointer;"><i class="fa-solid fa-circle-xmark"></i></button>
            </div>

            <!-- Menu Tabs -->
            <div class="menu-tabs-wrapper scroll-reveal">
                <div class="menu-tabs">
                    <button class="tab-btn active" data-category="all">Featured</button>
                    <button class="tab-btn" data-category="starter">Starters & Salads</button>
                    <button class="tab-btn" data-category="soup">Soup & Noodles</button>
                    <button class="tab-btn" data-category="main">Main Courses</button>
                    <button class="tab-btn" data-category="pizza">Burgers & Pizzas</button>
                    <button class="tab-btn" data-category="platters">Platters</button>
                    <button class="tab-btn" data-category="drinks">Drinks & Desserts</button>
                </div>
            </div>

            <!-- Menu Grid (Populated dynamically via JavaScript) -->
            <div class="menu-grid scroll-reveal" id="menu-grid">
                <!-- Dynamic cards will be rendered here -->
            </div>
            
            <div class="text-center scroll-reveal load-more-container" style="margin-top: 3rem;">
                <button class="btn btn-secondary" id="load-more-btn">Load All Dishes</button>
            </div>
        </div>
    </section>

<?php get_footer(); ?>
